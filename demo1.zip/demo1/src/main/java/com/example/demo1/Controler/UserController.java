package com.example.demo1.Controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.Service.IUserSer;

@RestController
public class UserController {
	
	@Autowired
	private IUserSer userService; 
	
	//1.addUserDetails
	
	

}
