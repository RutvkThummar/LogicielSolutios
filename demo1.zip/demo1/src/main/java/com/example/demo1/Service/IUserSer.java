package com.example.demo1.Service;

import java.util.List;

import com.example.demo1.Entity.User;

public interface IUserSer {


	    List<User> findAll();
	    User findById(Long id);
	    User saveUser(User user);
	    void deleteById(Long id);

}
