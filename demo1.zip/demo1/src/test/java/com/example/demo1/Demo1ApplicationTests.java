package com.example.demo1;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.example.demo1.Entity.User;
import com.example.demo1.Service.UserSerImpl;

@SpringBootTest

@TestMethodOrder(OrderAnnotation.class)
class Demo1ApplicationTests {
	

    @Autowired
    private UserSerImpl userService ;

	
	
	@Test
	@Order(1)
	//@Rollback(value = false)
	public void	saveUserTest() {
		
		 User savedUser = userService.saveUser(new User("rutvik@gmail.com", "rutvik"));
//		 User savedUser2 = userService.saveUser(new User("yash@gmail.com", "yash"));
	     
		    assertThat(savedUser.getId()).isGreaterThan(0);
	}
	
	@Test
	@Order(2)
	public void testFindUserById() {
		User user = userService.findById(1L);
		System.out.println(user);
	    assertThat(user.getId()).isEqualTo(1L);
	}
	
	@Test
	@Order(4)
	public void testListUsers() {
	    List<User> users = (List<User>) userService.findAll();
	    System.out.println(users);
	    assertThat(users).size().isGreaterThan(0);
	}
		
	
	
	@Test
	@Order(3)
	//@Rollback(false)
	public void testUpdateUser() {
		User user1 = userService.findById(2L);
		System.out.println(user1);
	    user1.setEmail("rutu@gmail.com");
	     
	    userService.saveUser(user1);
	     
	    User updatedUser = userService.findById(2L);
	     
	    assertThat(updatedUser.getEmail()).isEqualTo("rutu@gmail.com");
	}
	
	@Test
	@Order(5)
	@Rollback(false)
	public void testDeleteUser() {
	    User User = userService.findById(2L);
	     
	    userService.deleteById(User.getId());
	     
	    User deletedUser = userService.findById(2l);
	     
	    assertThat(deletedUser).isNull();       
	     
	}
	

}
